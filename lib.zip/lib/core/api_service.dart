class ApiService {
  static const String baseUrl = "http://localhost:3000/api";
}
