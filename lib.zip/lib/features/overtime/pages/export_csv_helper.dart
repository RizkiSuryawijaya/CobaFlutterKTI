import 'dart:io';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/ess_overtime_request.dart';

class ExportCSVHelper {
  static Future<void> exportToCSV(List<EssOvertimeRequest> list) async {
    List<List<String>> rows = [
      ["Tanggal", "Jam Mulai", "Jam Selesai", "Durasi", "Status", "Alasan/Remark"]
    ];

    for (var item in list) {
      rows.add([
        item.overtimeDate,
        item.startTime,
        item.endTime,
        item.totalDuration ?? "-",
        item.status ?? "-",
        item.reason?.name ?? item.remarks ?? "-"
      ]);
    }

    String csvData = const ListToCsvConverter().convert(rows);

    final directory = await getApplicationDocumentsDirectory();
    final path = "${directory.path}/riwayat_lembur.csv";
    final file = File(path);
    await file.writeAsString(csvData);

    await Share.shareXFiles([XFile(file.path)], text: "Riwayat Lembur CSV");
  }
}
