import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../overtime/controllers/ess_overtime_history_controller.dart';
import '../../overtime/models/ess_overtime_request.dart';

// import helper
import '../pages/export_csv_helper.dart';
import '../pages/export_pdf_helper.dart';

class OvertimeHistoryPage extends StatefulWidget {
  const OvertimeHistoryPage({super.key});

  @override
  State<OvertimeHistoryPage> createState() => _OvertimeHistoryPageState();
}

class _OvertimeHistoryPageState extends State<OvertimeHistoryPage> {
  final EssOvertimeHistoryController controller = Get.put(
    EssOvertimeHistoryController(),
  );

  String _searchText = "";
  String? _selectedYear;
  DateTime? _startDate;
  DateTime? _endDate;

  // Ambil semua tahun unik dari data
  List<String> _getAvailableYears() {
    final years = controller.historyRequests
        .map((e) => DateTime.tryParse(e.overtimeDate)?.year.toString())
        .where((y) => y != null)
        .cast<String>()
        .toSet()
        .toList();
    years.sort((a, b) => b.compareTo(a)); // descending
    return years;
  }

  // Filter dinamis berdasarkan search, tahun, tanggal
  List<EssOvertimeRequest> _applyFilters() {
    var list = controller.historyRequests.toList();

    // Filter search text
    if (_searchText.isNotEmpty) {
      list = list.where((e) {
        final reason = e.reason?.name?.toLowerCase() ?? "";
        final remarks = e.remarks?.toLowerCase() ?? "";
        final status = e.status?.toLowerCase() ?? "";
        return reason.contains(_searchText.toLowerCase()) ||
            remarks.contains(_searchText.toLowerCase()) ||
            status.contains(_searchText.toLowerCase());
      }).toList();
    }

    // Filter tahun
    if (_selectedYear != null) {
      list = list.where((e) {
        final year = DateTime.tryParse(e.overtimeDate)?.year.toString();
        return year == _selectedYear;
      }).toList();
    }

    // Filter range tanggal
    if (_startDate != null && _endDate != null) {
      list = list.where((e) {
        final date = DateTime.tryParse(e.overtimeDate);
        if (date == null) return false;
        return date.isAfter(_startDate!.subtract(const Duration(days: 1))) &&
            date.isBefore(_endDate!.add(const Duration(days: 1)));
      }).toList();
    }

    return list;
  }

  // Pilih tanggal
  Future<void> _pickDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDateRange: _startDate != null && _endDate != null
          ? DateTimeRange(start: _startDate!, end: _endDate!)
          : null,
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
    }
  }

  // Reset semua filter
  void _resetFilters() {
    setState(() {
      _searchText = "";
      _selectedYear = null;
      _startDate = null;
      _endDate = null;
    });
  }

  // Warna status
  Color _getStatusColor(String? status) {
    if (status == null) return Colors.grey;
    switch (status.toLowerCase()) {
      case 'approved':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      case 'pending':
        return Colors.orange;
      default:
        return Colors.blue;
    }
  }

  // Dialog export
  void _showExportDialog(List<EssOvertimeRequest> list) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Export Data"),
        content: const Text("Pilih format export:"),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              ExportCSVHelper.exportToCSV(list);
            },
            child: const Text("Export CSV"),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              ExportPDFHelper.exportToPDF(list);
            },
            child: const Text("Export PDF"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Riwayat Lembur",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF1976D2),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () {
              final list = _applyFilters();
              if (list.isEmpty) {
                Get.snackbar("Info", "Tidak ada data untuk diexport");
              } else {
                _showExportDialog(list);
              }
            },
            tooltip: "Export Data",
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _resetFilters,
            tooltip: "Reset Filter",
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: "Cari alasan, remark, atau status...",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                isDense: true,
              ),
              onChanged: (value) {
                setState(() {
                  _searchText = value;
                });
              },
            ),
          ),

          // Filter dropdown & tanggal
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(
              children: [
                Expanded(
                  child: Obx(() {
                    final years = _getAvailableYears();
                    return DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: "Tahun",
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      value: _selectedYear,
                      items: years
                          .map(
                            (y) => DropdownMenuItem(value: y, child: Text(y)),
                          )
                          .toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedYear = value;
                        });
                      },
                    );
                  }),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.date_range),
                    label: Text(
                      _startDate == null
                          ? "Periode"
                          : "${DateFormat('dd/MM/yy').format(_startDate!)} - ${DateFormat('dd/MM/yy').format(_endDate!)}",
                    ),
                    onPressed: _pickDateRange,
                  ),
                ),
              ],
            ),
          ),

          // List data
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }

              final list = _applyFilters();

              if (list.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(
                        Icons.watch_later_outlined,
                        size: 80,
                        color: Colors.black26,
                      ),
                      SizedBox(height: 16),
                      Text(
                        "Tidak ada riwayat lembur",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.black54,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: list.length,
                itemBuilder: (context, index) {
                  final EssOvertimeRequest lembur = list[index];
                  final statusColor = _getStatusColor(lembur.status);

                  return Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Header
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                    Icons.date_range,
                                    color: Colors.black54,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    DateFormat("dd-MM-yyyy").format(
                                      DateTime.parse(lembur.overtimeDate),
                                    ),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: statusColor.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  lembur.status ?? 'Pending',
                                  style: TextStyle(
                                    color: statusColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 24),
                          _buildDetailRow(
                            icon: Icons.access_time,
                            label: "Jam",
                            value:
                                "${lembur.startTime} - ${lembur.endTime ?? 'N/A'}",
                          ),
                          _buildDetailRow(
                            icon: Icons.timer,
                            label: "Durasi",
                            value: "${lembur.totalDuration ?? '-'} jam",
                          ),
                          _buildDetailRow(
                            icon: Icons.description,
                            label: "Alasan",
                            value:
                                lembur.reason?.name ??
                                lembur.remarks ??
                                'Tidak ada',
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: Colors.black54),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.black54,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
