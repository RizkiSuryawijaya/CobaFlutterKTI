import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/ess_overtime_request_controller.dart';
import '../../../routes/app_routes.dart';

class OvertimeListPage extends StatelessWidget {
  const OvertimeListPage({super.key});

  Color _getStatusColor(String? status) {
    switch (status?.toLowerCase()) {
      case "approved":
        return Colors.green[700]!;
      case "rejected":
        return Colors.red[700]!;
      case "pending":
        return Colors.orange[700]!;
      default:
        return Colors.grey[600]!;
    }
  }

  @override
  Widget build(BuildContext context) {
    final EssOvertimeRequestController controller = Get.put(
      EssOvertimeRequestController(),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Daftar Pengajuan Lembur",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue[900],
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.overtimeRequests.isEmpty) {
          return const Center(
            child: Text(
              "Tidak ada data lembur.",
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          itemCount: controller.overtimeRequests.length,
          itemBuilder: (context, index) {
            final overtime = controller.overtimeRequests[index];

            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Bagian Atas: Nama Pengaju dan Status
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Nama Pengaju
                        Expanded(
                          child: Text(
                            overtime.user?.name ?? 'Nama Tidak Diketahui',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Colors.black87,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 10),
                        // Status
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: _getStatusColor(overtime.status),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            overtime.status ?? "-",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 24, thickness: 1, color: Colors.black12),

                    // Bagian Alasan Lembur
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.assignment,
                                size: 18, color: Colors.blueGrey),
                            const SizedBox(width: 8),
                            Text(
                              'Alasan Lembur',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[700],
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Padding(
                          padding: const EdgeInsets.only(left: 26.0),
                          child: Text(
                            overtime.reason?.name ?? 'Tanpa Alasan',
                            style: const TextStyle(
                              fontSize: 15,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    // Detail Lembur
                    _buildDetailRow(
                      icon: Icons.calendar_today,
                      label: 'Tanggal',
                      value:
                          '${overtime.overtimeDate}${overtime.endDate != null ? ' - ${overtime.endDate}' : ''}',
                    ),
                    const SizedBox(height: 8),
                    _buildDetailRow(
                      icon: Icons.access_time,
                      label: 'Waktu',
                      value: '${overtime.startTime} - ${overtime.endTime}',
                    ),
                    if (overtime.totalDuration != null) ...[
                      const SizedBox(height: 8),
                      _buildDetailRow(
                        icon: Icons.timelapse,
                        label: 'Durasi',
                        value: overtime.totalDuration!,
                      ),
                    ],
                    const SizedBox(height: 8),
                    _buildDetailRow(
                      icon: Icons.notes,
                      label: 'Catatan',
                      value: overtime.remarks != null && overtime.remarks!.isNotEmpty
                          ? overtime.remarks!
                          : "-",
                    ),

                    // Aksi (Edit & Delete)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, color: Colors.blue, size: 24),
                          tooltip: 'Edit',
                          onPressed: () {
                            Get.toNamed(
                              AppRoutes.updateOvertime,
                              arguments: overtime,
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red, size: 24),
                          tooltip: 'Hapus',
                          onPressed: () {
                            Get.dialog(
                              AlertDialog(
                                title: const Text('Hapus Data'),
                                content: const Text(
                                  'Apakah Anda yakin ingin menghapus data ini?',
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Get.back(),
                                    child: const Text('Batal'),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      controller.deleteOvertime(
                                        overtime.overtimeId!,
                                      );
                                      Get.back();
                                    },
                                    child: const Text('Hapus'),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      }),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Get.toNamed(AppRoutes.applyOvertime),
        label: const Text('Ajukan Lembur'),
        icon: const Icon(Icons.add),
        backgroundColor: Colors.blue[900],
      ),
    );
  }

  // Widget pembantu untuk membuat baris detail yang seragam
  Widget _buildDetailRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 18, color: Colors.blueGrey),
        const SizedBox(width: 8),
        Text(
          '$label :',
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.black54,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(fontSize: 14, color: Colors.black87),
          ),
        ),
      ],
    );
  }
}
