class EssReasonOT {
  final String? reasonId;
  final String name;

  EssReasonOT({
    this.reasonId,
    required this.name,
  });

  factory EssReasonOT.fromJson(Map<String, dynamic> json) {
    return EssReasonOT(
      reasonId: json['reason_id'] as String?, //  sesuai backend
      name: json['name'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'reason_id': reasonId,
      'name': name,
    };
  }
}
