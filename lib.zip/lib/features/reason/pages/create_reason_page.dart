import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/ess_reason_ot_controller.dart';

class CreateReasonPage extends StatelessWidget {
  final TextEditingController _nameController = TextEditingController();
  final EssReasonOTController reasonController = Get.find();

  CreateReasonPage({super.key});

  void _submit() {
    if (_nameController.text.isNotEmpty) {
      // ✅ pake addReason yang ada di controller
      reasonController.addReason(_nameController.text);
      Get.back(); // kembali ke list setelah create
    } else {
      Get.snackbar("Error", "Nama reason tidak boleh kosong!");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tambah Reason"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Nama Reason",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: "Masukkan nama reason",
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submit,
                child: const Text("Simpan"),
              ),
            )
          ],
        ),
      ),
    );
  }
}
