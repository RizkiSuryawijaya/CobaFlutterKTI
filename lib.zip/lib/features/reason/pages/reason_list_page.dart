import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/ess_reason_ot_controller.dart';
import '../models/ess_reason_ot.dart';
import '../../../routes/app_routes.dart';

class ReasonListPage extends StatelessWidget {
  const ReasonListPage({super.key});

  @override
  Widget build(BuildContext context) {
    final EssReasonOTController controller = Get.put(EssReasonOTController());

    return Scaffold(
      appBar: AppBar(
        title: const Text("Daftar Reason OT"),
        backgroundColor: Colors.blue[900],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.reasons.isEmpty) {
          return const Center(
            child: Text(
              "Belum ada reason",
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          );
        }

        return ListView.builder(
          itemCount: controller.reasons.length,
          itemBuilder: (context, index) {
            final EssReasonOT reason = controller.reasons[index];

            return Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 2,
              child: ListTile(
                title: Text(
                  reason.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () {
                        Get.toNamed(
                          AppRoutes.updateReason,
                          arguments: reason,
                        );
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        Get.dialog(
                          AlertDialog(
                            title: const Text('Hapus Reason'),
                            content: const Text(
                              'Apakah Anda yakin ingin menghapus reason ini?',
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Get.back(),
                                child: const Text('Batal'),
                              ),
                              TextButton(
                                onPressed: () {
                                  controller.deleteReason(reason.reasonId!);
                                  Get.back();
                                },
                                child: const Text('Hapus'),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        );
      }),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Get.toNamed(AppRoutes.createReason),
        label: const Text('Tambah Reason'),
        icon: const Icon(Icons.add),
        backgroundColor: Colors.blue[900],
      ),
    );
  }
}
