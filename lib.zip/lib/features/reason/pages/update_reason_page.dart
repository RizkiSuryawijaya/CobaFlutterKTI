import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/ess_reason_ot_controller.dart';
import '../models/ess_reason_ot.dart';

class UpdateReasonPage extends StatelessWidget {
  final EssReasonOT reason;
  final controller = Get.find<EssReasonOTController>();
  final TextEditingController nameController = TextEditingController();

  UpdateReasonPage({super.key, required this.reason}) {
    nameController.text = reason.name;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Update Reason")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: "Nama Reason"),
            ),
            const SizedBox(height: 20),
            Obx(() => ElevatedButton(
                  onPressed: controller.isLoading.value
                      ? null
                      : () {
                          controller.updateReason(
                            reason.reasonId!,
                            nameController.text,
                          );
                          Get.back();
                        },
                  child: controller.isLoading.value
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text("Update"),
                )),
          ],
        ),
      ),
    );
  }
}
