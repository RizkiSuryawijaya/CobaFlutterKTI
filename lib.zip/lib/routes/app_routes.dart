abstract class AppRoutes {
  // Auth
  static const login = '/';

  // Dashboard
  static const adminDashboard = '/admin';
  static const karyawanDashboard = '/karyawan';

  // Overtime
  static const overtimeList = '/listlembur';
  static const applyOvertime = '/apply-overtime';
  static const updateOvertime = '/update-overtime';

  // History
  static const overtimeHistory = '/overtime-history';

  // Reason
  static const String createReason = '/reason-create';
  static const reasonList = '/reason-list';
  static const updateReason = '/reason-update';



}
